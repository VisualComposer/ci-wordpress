<?php
/*
   Template Name: Sub Dir 
 */
?>