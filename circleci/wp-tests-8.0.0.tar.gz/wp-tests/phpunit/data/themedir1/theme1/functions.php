<?php

// dummy theme

echo dirname(__FILE__).'/'.basename(__FILE__);

?>
